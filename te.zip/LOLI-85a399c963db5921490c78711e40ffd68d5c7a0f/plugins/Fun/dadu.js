let handler = async (m, { conn }) => {
m.reply('sedang error')
}
handler.help = ['dadu']
handler.tags = ['game']
handler.command = ['dadu'] 
export default handler
